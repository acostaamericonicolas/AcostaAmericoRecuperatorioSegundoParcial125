package modelo;

import java.io.Serializable;
import java.time.LocalDate;
import servicio.CSVSerializable;

public class ReservaViaje<T> extends Reserva implements Serializable, Comparable<ReservaViaje>, CSVSerializable{
    private static final long serialVersionUID = 1L;
    private String destino;
    private TipoTransporte transporte;

    
    public ReservaViaje(int id, String pasajero, LocalDate fecha, String destino, TipoTransporte transporte) {
        super(id, pasajero, fecha);
        this.destino = destino;
        this.transporte = transporte;
    }

    public String getDestino() {
        return destino;
    }

    public TipoTransporte getTransporte() {
        return transporte;
    }

    @Override
    public String toString() {
        return "ReservaViaje{" + "id=" + getId() + "pasajero=" + getPasajero() + "fecha=" + getFecha() + "destino=" + destino + "destino=" + destino + ", transporte=" + transporte + '}';
    }
    
    
    @Override
    public int compareTo(ReservaViaje o) {
        return fecha.compareTo(o.fecha);
    }

    @Override
    public String toCSV() {
        return  getId() + "," + getPasajero() + "," +getFecha() + "," + destino +"," +transporte.toString();
        
    }

    @Override
    public String toHeaderCSV() {
        return "id,pasajero,fecha,festino,tipoTransporte";
    }
    
    public static ReservaViaje fromCSV(String reservaCSV){
        String[] values = reservaCSV.split(",");
        ReservaViaje toReturn = null;
            if(values.length == 5){
                int id = Integer.parseInt(values[0]);
                String pasajero = values[1];
                LocalDate fecha = LocalDate.parse(values[2]);
                String destino = values[3];
                TipoTransporte transporte = TipoTransporte.valueOf(values[4]);
                toReturn = new ReservaViaje(id, pasajero, fecha, destino, transporte);
            }
        return toReturn;
    }

    
}
