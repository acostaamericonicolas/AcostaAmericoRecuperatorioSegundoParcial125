package config;

import java.time.LocalDate;

public class AppConfig {
    public static String PATH_CSV = "src/data/reservas.csv";
    public static String PATH_BIN = "src/data/reservas.dat";
    public static  LocalDate INICIO = LocalDate.parse("2024-12-01");  
    public static LocalDate FIN = LocalDate.parse("2024-12-31");
    }
        
    //defina las rutas de los archivos de almacenamiento en carpetas predefinidas..

    
    

