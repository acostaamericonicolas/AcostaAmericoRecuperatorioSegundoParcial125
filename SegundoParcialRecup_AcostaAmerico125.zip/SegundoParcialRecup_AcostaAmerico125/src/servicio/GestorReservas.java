package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GestorReservas<T extends CSVSerializable> implements Gestionable<T>{
    List<T> items = new ArrayList<>();

    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("El objeto a agregar no puede ser nulo");
        }
        items.add(item);
    }

    @Override
    public T eliminar(int indice) {
        if (indice < 0 || indice >= items.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango: " + indice);
        }
        return items.remove(indice);
    }

    @Override
    public T obtener(int indice) {
        return null;
    }

    @Override
    public void limpiarElementos() {
        items.clear();
     }

    @Override
    public void mostrarTodos() {
        for(T item: items){
            System.out.println(item);
        }
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicate) {
        List<T> toReturn = new ArrayList<>();
        for(T item : items){
        if(predicate.test(item)){
            toReturn.add(item);
        }            
        }
        return toReturn;
    }

    @Override
    public void guardarEnBinario(String path) throws IOException {
        if (path == null || path.isEmpty()) {
            throw new IllegalArgumentException("La ruta del archivo no puede ser nula o vacía");
        }
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(items);
            salida.close(); 
        }
    }

    @Override
    public void cargarDesdeBinario(String path) throws IOException {
        if (path == null || path.isEmpty()) {
            throw new IllegalArgumentException("La ruta del archivo no puede ser nula o vacía");
        }
        //items.clear(); // limpio la lista 
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))){
            items = (List<T>) entrada.readObject();
            entrada.close(); 
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestorReservas.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            throw new FileNotFoundException("Archivo no encontrado: " + path);
        }}

    @Override
    public void guardarEnCSV(String path) throws IOException {
        if (path == null || path.isEmpty()) {
            throw new IllegalArgumentException("La ruta del archivo no puede ser nula o vacía");
        }
        if (items.isEmpty()) {
            throw new IllegalStateException("El gestor de reservas está vacío. No hay datos para guardar en el archivo CSV");
        }
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){   
            for(T item:items){
                bw.write(item.toCSV() + "\n");
            }
            bw.close();
        }
    }

   @Override
    public void cargarDesdeCSV(String path, Function<String, T> trasformadora) throws IOException{
        try{
            BufferedReader br = new BufferedReader(new FileReader(path));
            String linea = "";
            while((linea = br.readLine()) != null){
                if(linea.endsWith("\n")){
                linea = linea.substring(linea.length() -1);
                items.add(trasformadora.apply(linea));
                }
            }
            br.close();
        } catch (FileNotFoundException ex){
            System.out.println(ex.getMessage());
        } 
    }

 
    
}
